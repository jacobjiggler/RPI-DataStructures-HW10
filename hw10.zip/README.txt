HOMEWORK 10: MULTIPLE INHERITANCE & EXCEPTIONS


NAME:  Jacob Martin


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassment, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.
Nathan Hourt(parallelogram/Isos Triangle clarification)


Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

I learned a lot this semester. Thank you




